import {
  BookConfigurationManager
} from "@/components/configurator/BookConfigurationManager/BookConfigurationManager";

export const Configurator = () => {
  return (
    <>
      <BookConfigurationManager/>
    </>
  )
}
