import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { BaseLayout } from '@/components/layout/BaseLayout/BaseLayout';
import {ReactNode} from "react";
import {Configurator} from "@/pages/Configurator/Configurator";
import {ConfigurationCard} from "@/pages/Configurator/ConfigurationCard";
import {BlockCard} from "@/pages/Configurator/BlockCard";

const router = createBrowserRouter([
  {
    path: '/',
    element: <BaseLayout/> as ReactNode,
    children: [
      {
        path: '/configurator',
        element: <Configurator/> as ReactNode
      },
      {
        path: '/configuration/edit',
        element: <ConfigurationCard/> as ReactNode
      },
      {
        path: '/block/edit',
        element: <BlockCard/> as ReactNode
      }
    ]
  },
]);

export function Router() {
  return <RouterProvider router={router} />;
}
