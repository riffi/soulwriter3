import {useLiveQuery} from "dexie-react-hooks";
import { generateUUID } from '@/utils/UUIDUtils';
import {IBookConfiguration} from "@/entities/ConstructorEntities";
import {configDatabase} from "@/entities/db";
export const useConfigurationManager = () => {
  const configurationList = useLiveQuery<IBookConfiguration[]>(async () => {
    return configDatabase.bookConfigurations.toArray();
  }, [])

  const saveConfiguration = async (configuration: IBookConfiguration) => {
    if (configuration.uuid){
      await configDatabase.bookConfigurations.update(configuration.id, configuration)
      return
    }

    configuration.uuid = generateUUID()
    await configDatabase.bookConfigurations.put(configuration)
  }

  const removeConfiguration = async (configuration: IBookConfiguration) => {
    await configDatabase.bookConfigurations.delete(configuration.id)
  }

  return {
    configurationList,
    saveConfiguration,
    removeConfiguration
  }
}
