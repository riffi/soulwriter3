import {
  ActionIcon,
  Anchor,
  Breadcrumbs,
  Button,
  Card,
  Container,
  Grid,
  Group, SimpleGrid,
  Space,
  Text
} from "@mantine/core";
import React, {useState} from "react";
import {
  useBookConfigurationEditForm
} from "@/components/configurator/BookConfigurationEditForm/useBookConfigurationEditForm";
import {IconEdit, IconSettings, IconTrash} from "@tabler/icons-react";
import {
  ConfigurationEditModal
} from "@/components/configurator/BookConfigurationManager/ConfigurationEditModal/ConfigurationEditModal";
import {notifications} from "@mantine/notifications";
import {IBlock, IBookConfiguration} from "@/entities/ConstructorEntities";
import {
  BlockEditModal
} from "@/components/configurator/BookConfigurationEditForm/BlockEditModal/BlockEditModal";
import {useNavigate} from "react-router-dom";



export const BookConfigurationEditForm = ({bookConfigurationUuid}: {bookConfigurationUuid: string}) => {

  const navigate = useNavigate()

  const {
    bookConfiguration,
    blockList,
    saveBlock,
    paramGroupList
  } = useBookConfigurationEditForm(bookConfigurationUuid)

  const getBlackBlock = (): IBlock => {
    return {
      configurationUuid: bookConfigurationUuid,
      uuid: '',
      title: '',
      description: '',
      useTabs: false
    }
  }

  const [isModalOpened, setIsModalOpened] = useState<boolean>(false)
  const [currentBlock, setCurrentBlock] = useState<IBookConfiguration>(getBlackBlock())

  const breadCrumbs = [
    { title: 'Конфигуратор', href: '/configurator' },
    { title: bookConfiguration?.title, href: '#' },
  ].map((item, index) => (
      <Anchor href={item.href} key={index}>
        {item.title}
      </Anchor>
  ));

  return (
      <>
        <Container fluid>
          <h1>Конфигурация: {bookConfiguration?.title}</h1>
          <Breadcrumbs separator="→" separatorMargin="md" mt="xs">
            {breadCrumbs}
          </Breadcrumbs>
          <Space h={20}/>
          <Text size="xl">Строительные блоки</Text>
          <Button
            onClick={() => {
              setCurrentBlock(getBlackBlock())
              setIsModalOpened(true)
            }}
          >
            Добавить
          </Button>
          <Space h={20}/>
          <SimpleGrid cols={{ base: 1, sm: 2, lg: 2, xl: 5 }}>
            {blockList?.map((c) =>
                <Card key={c.uuid}>
                  <Group justify="space-between" mt="md" mb="xs">
                    <Button
                        variant={"subtle"}
                        onClick={() => {navigate(`/block/edit?uuid=${c.uuid}`)}}
                    >
                      {c.title}
                    </Button>
                    <ActionIcon
                        color={"var(--mantine-color-red-9)"}
                        variant={"subtle"}
                        onClick={() => {
                        //  removeConfiguration(c)
                        }}
                    >
                      <IconTrash/>
                    </ActionIcon>
                  </Group>
                  <Text size="sm" c="dimmed">{c.description}</Text>
                  <Group style={{marginTop: '10px'}}>
                    <Button
                        color="blue"
                        radius="md"
                        variant={"outline"}
                        leftSection={<IconEdit/>}
                        onClick={() => {
                          setCurrentBlock(c)
                          setIsModalOpened(true)
                        }}
                    >
                      Переименовать
                    </Button>
                  </Group>
                </Card>
            )}
          </SimpleGrid>

        </Container>

        {isModalOpened && <BlockEditModal
            isOpen={isModalOpened}
            configurationUuid={bookConfigurationUuid}
            onClose={() => setIsModalOpened(false)}
            onSave={(c) => {
              notifications.show({
                title: 'Блок',
                message: `Блок "${c.title}" сохранён`,
              })
              saveBlock(c)
            }}
            initialData={currentBlock}
        />}
      </>
  )
}
