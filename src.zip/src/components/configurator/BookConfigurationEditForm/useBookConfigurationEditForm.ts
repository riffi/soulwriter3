import { useLiveQuery } from 'dexie-react-hooks';
import {IBlock, IBlockParameterGroup, IBookConfiguration} from "@/entities/ConstructorEntities";
import {configDatabase} from "@/entities/db";
import {generateUUID} from "@/utils/UUIDUtils";

export const useBookConfigurationEditForm = (uuid: string, currentBlock?: IBlock) => {

  // Данные конфигурации
  const bookConfiguration = useLiveQuery<IBookConfiguration>(() =>{
    return configDatabase.bookConfigurations.where('uuid').equals(uuid).first();
  }, [])

  // Список строительных блоков конфигурации
  const blockList = useLiveQuery<IBlock[]>(() => {
    return configDatabase.blocks.where('configurationUuid').equals(uuid).toArray();
  }, [uuid])

  // Список групп параметров для строительного блока
  const paramGroupList = useLiveQuery<IBlockParameterGroup[]>(() => {
    if (!currentBlock) {
      return []
    }
    return configDatabase.blockParameterGroups.where('blockUuid').equals(currentBlock?.uuid).toArray();
  }, [currentBlock])


  const appendDefaultParamGroup = async (blockData: IBlock) => {
    await configDatabase.blockParameterGroups.add({
      blockUuid: blockData.uuid,
      uuid: generateUUID(),
      orderNumber: 0,
      description: '',
      title: 'Основное'
    })
  }
  const saveBlock = async (blockData: IBlock) => {
    if (!blockData.uuid) {
      blockData.uuid = generateUUID()
      const blockId = await configDatabase.blocks.add(blockData)
      const persistedBlockData = await configDatabase.blocks.get(blockId)
      await appendDefaultParamGroup(persistedBlockData)
      return
    }
    configDatabase.blocks.update(blockData.id, blockData)
  }

  return {
    bookConfiguration,
    blockList,
    paramGroupList,
    saveBlock
  }
}
