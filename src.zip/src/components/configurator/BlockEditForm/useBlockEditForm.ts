import { useLiveQuery } from 'dexie-react-hooks';
import {IBlock, IBlockParameter, IBlockParameterGroup} from "@/entities/ConstructorEntities";
import {configDatabase} from "@/entities/db";
import {generateUUID} from "@/utils/UUIDUtils";

export const useBlockEditForm = (blockUuid: string, currentGroupUuid?: string) => {

  const block = useLiveQuery<IBlock>( () => {
    return configDatabase.blocks.where("uuid").equals(blockUuid).first()
  }, [blockUuid])

  const paramGroupList = useLiveQuery<IBlockParameterGroup[]>(() => {
    return configDatabase.blockParameterGroups.where("blockUuid").equals(blockUuid).toArray();
  }, [block])

  const paramList = useLiveQuery<IBlockParameter[]>(() => {
    if (!currentGroupUuid) {
      return []
    }
    return configDatabase.blockParameters.where({groupUuid : currentGroupUuid }).toArray();
  }, [currentGroupUuid]);

  const configuration = useLiveQuery(() => {
    if (!block) return undefined
    return configDatabase.bookConfigurations.where("uuid").equals(block?.configurationUuid).first()
  }, [block?.uuid])

  const saveParamGroup = async (data: IBlockParameterGroup) => {
    if (!data.uuid) {
      data.uuid = generateUUID()
      const blockId = await configDatabase.blockParameterGroups.add(data)
      return
    }
    configDatabase.blockParameterGroups.update(data.id, data)
  }


  const saveBlock = async (blockData: IBlock) => {
    if (!blockData.uuid) {
      blockData.uuid = generateUUID()
      const blockId = await configDatabase.blocks.add(blockData)
      const persistedBlockData = await configDatabase.blocks.get(blockId)
      await appendDefaultParamGroup(persistedBlockData)
      return
    }
    configDatabase.blocks.update(blockData.id, blockData)
  }

  const saveParam = (param: IBlockParameter) => {
    if (!param.id) {
      param.uuid = generateUUID()
      param.groupUuid = currentGroupUuid;
      param.orderNumber = paramList?.length
      configDatabase.blockParameters.add(param);
    }
    else{
      configDatabase.blockParameters.update(param.id, param);
    }
  }

  const appendDefaultParamGroup = async (blockData: IBlock) => {
    await configDatabase.blockParameterGroups.add({
      blockUuid: blockData?.uuid,
      uuid: generateUUID(),
      orderNumber: 0,
      description: '',
      title: 'Основное'
    })
  }

  return {
    block,
    saveBlock,
    paramGroupList,
    saveParamGroup,
    configuration,
    paramList,
    saveParam
  }
}
