import {
  ActionIcon,
  Anchor,
  Breadcrumbs,
  Button,
  Checkbox,
  Container,
  Space,
  Table,
  Tabs
} from "@mantine/core";
import {useBlockEditForm} from "@/components/configurator/BlockEditForm/useBlockEditForm";
import React, {useState} from "react";
import {IBlockParameter} from "@/entities/ConstructorEntities";

import {notifications} from "@mantine/notifications";
import {
  ParamEditModal
} from "@/components/configurator/BlockEditForm/ParamEditModal/ParamEditModal";
import {Icon2fa, IconEdit} from "@tabler/icons-react";

interface IBlockEditFormProps {
  blockUuid: string
}

export const BlockEditForm = (props: IBlockEditFormProps) => {

  const [currentGroupUuid, setCurrentGroupUuid] = useState<string>()
  const [currentParam, setCurrentParam] = useState<IBlockParameter>()
  const [isModalOpened, setIsModalOpened] = useState<boolean>(false)
  const {
    saveParamGroup,
    paramGroupList,
    block,
    saveBlock,
    configuration,
    paramList,
    saveParam
  } = useBlockEditForm(props.blockUuid, currentGroupUuid)

  const getInitialData = (): IBlockParameter =>{
    return {
      uuid: '',
      title: '',
      description: '',
      groupUuid: currentGroupUuid,
      dataType: 'string',
      orderNumber: paramList?.length
    }
  }

  const breadCrumbs = [
    { title: 'Конфигуратор', href: '/configurator' },
    { title: configuration?.title, href: '/configuration/edit?uuid=' + configuration?.uuid },
    { title: block?.title, href: '#' },
  ].map((item, index) => (
      <Anchor href={item.href} key={index}>
        {item.title}
      </Anchor>
  ));

  const paramTableRows = paramList?.map((param) => (
      <Table.Tr key={param.uuid}>
        <Table.Td>{param.orderNumber}</Table.Td>
        <Table.Td>{param.title}</Table.Td>
        <Table.Td>{param.dataType}</Table.Td>
        <Table.Td>
          <ActionIcon
              onClick={() => {
                setCurrentParam({...param})
                setIsModalOpened(true)
              }}
          >
            <IconEdit/>
          </ActionIcon>
        </Table.Td>
      </Table.Tr>
  ));

  return (
    <>
      <Container fluid>
        <h1>Блок: {block?.title}</h1>
        <Breadcrumbs separator="→" separatorMargin="md" mt="xs">
          {breadCrumbs}
        </Breadcrumbs>
        <Space h="md"/>
        <Checkbox
            checked={block?.useTabs}
            label="Использовать вкладки"
            onChange={(e) => {
              saveBlock({...block, useTabs: e.currentTarget.checked})
            }}
        />
        {block?.useTabs && (<Tabs
            defaultValue={paramGroupList?.at(0)?.uuid}
            onChange={(value) => {setCurrentGroupUuid(value)}}
        >
          <Tabs.List>
            {paramGroupList?.map(p =>
                <Tabs.Tab value={p.uuid} key={p.uuid}>
                  {p.title}
                </Tabs.Tab>
            )}
          </Tabs.List>
          {paramGroupList?.map(p =>
            <Tabs.Panel value={p.uuid} key={p.uuid}>
              <Space h="md"/>
              <Button
                  onClick={() => {
                    setIsModalOpened(true)
                    setCurrentParam(getInitialData())
                  }}
              >
                Добавить параметр
              </Button>
              <Table>
                <Table.Thead>
                  <Table.Tr>
                    <Table.Th>#</Table.Th>
                    <Table.Th>Название</Table.Th>
                    <Table.Th>Тип данных</Table.Th>
                    <Table.Th>Действия</Table.Th>
                  </Table.Tr>
                </Table.Thead>
                <Table.Tbody>{paramTableRows}</Table.Tbody>
              </Table>
            </Tabs.Panel>
          )}
          </Tabs>)
        }
      </Container>
      {isModalOpened && <ParamEditModal
          isOpen={isModalOpened}
          onClose={() => setIsModalOpened(false)}
          onSave={(c) => {
            notifications.show({
              title: 'Параметр',
              message: `Параметр "${c.title}" сохранён`,
            })
            saveParam(c)
          }}
          initialData={currentParam}
      />}
    </>
  )
}
