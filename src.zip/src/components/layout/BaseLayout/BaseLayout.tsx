import {useDisclosure} from "@mantine/hooks";
import {AppShell, Burger, Group, Text} from "@mantine/core";
import {NavbarNested} from "@/components/layout/NavbarNested/NavbarNested";
import {Outlet} from "react-router-dom";

export const BaseLayout = () =>  {
  const [opened, { toggle }] = useDisclosure();

  return (
      <>
        <AppShell
            header={
              {
                height: {base:60, sm: 0, lg: 0},
              }
            }
            navbar={{
              width: 300,
              breakpoint: 'sm',
              collapsed: { mobile: !opened },
            }}
            padding="md"
        >
          <AppShell.Header>
            <Group>
              <Burger
                  opened={opened}
                  onClick={toggle}
                  hiddenFrom="sm"
                  lineSize={1} size="lg"
                  style={{paddingTop: 20, paddingLeft: 10}}
              />
            </Group>
          </AppShell.Header>

          <AppShell.Navbar>
            <NavbarNested/>
          </AppShell.Navbar>

          <AppShell.Main>
            <Outlet/>
          </AppShell.Main>
        </AppShell>

      </>
  );
}
